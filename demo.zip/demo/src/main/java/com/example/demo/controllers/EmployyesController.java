package com.example.demo.controllers;

import com.example.demo.models.Test;
import com.example.demo.models.employees;
import com.example.demo.models.posts;
import com.example.demo.repos.employeeRepos;
import com.example.demo.repos.postsRepos;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Controller
public class EmployyesController {

    @Autowired
    private employeeRepos EmployeesRepos;
    @Autowired
    private postsRepos EmployeePostsRepos;


    @GetMapping("/employees")
    public String employeesSelect(Model model){



        Iterable<employees> employees = EmployeesRepos.findAll();
        model.addAttribute("employees", employees);

        System.out.println(employees);

        return "employeesSelect";
    }
    @GetMapping("employees/create")
    public String employeesCreate(Model model){
        ArrayList<posts> es = new ArrayList<>();
        Iterable<posts> empList = EmployeePostsRepos.findAll();
        for (posts e:empList) {
            es.add(e);
        }

        model.addAttribute("es", es);
        return "employeesCreate";
    }

    @PostMapping("/employees/create")
    public String employeesCreateAction(Model model, @RequestParam String name, @RequestParam String salary, @RequestParam String address, @RequestParam posts posts){


        employees em = new employees(name, salary,address, posts);
        EmployeesRepos.save(em);


        return "redirect:/employees";
    }


    @GetMapping("employees/edit/{id}")
    public String employeesEdit(Model model, Model mod, @PathVariable(value = "id") Long id){

        ArrayList<posts> es = new ArrayList<>();
        Iterable<posts> empList = EmployeePostsRepos.findAll();
        for (posts e:empList) {
            es.add(e);
        }

        mod.addAttribute("es", es);

        Optional<employees> employeesOp = EmployeesRepos.findById(id);
        ArrayList<employees> res = new ArrayList<>();
        employeesOp.ifPresent(res::add);
        model.addAttribute("employees", res);

        return "employeesEdit";
    }

    @PostMapping("employees/edit/{id}")
    public String employeesEditAction(Model model, @PathVariable(value = "id") Long id, @RequestParam String name, @RequestParam String salary, @RequestParam String address, @RequestParam posts posts){

        employees em = EmployeesRepos.findById(id).orElseThrow();
        em.setName(name);
        em.setPosts(posts);
        em.setSalary(salary);
        em.setAddress(address);
        EmployeesRepos.save(em);

        return "redirect:/employees";
    }

    @GetMapping("employees/delete/{id}")
    public String employeesDelete(Model model, @PathVariable(value = "id") Long id){

        Optional<employees> employeesOp = EmployeesRepos.findById(id);
        ArrayList<employees> res = new ArrayList<>();
        employeesOp.ifPresent(res::add);
        model.addAttribute("employees", res);

        return "employeesDelete";
    }

    @PostMapping("employees/delete/{id}")
    public String employeesDeleteAction(Model model, @PathVariable(value = "id") Long id){

        EmployeesRepos.deleteById(id);

        return "redirect:/employees";
    }





}
