package com.example.demo.repos;

import com.example.demo.models.employees;
import org.springframework.data.repository.CrudRepository;

public interface employeeRepos extends CrudRepository<employees, Long> {
}
