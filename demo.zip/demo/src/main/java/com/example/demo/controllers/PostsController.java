package com.example.demo.controllers;



import com.example.demo.models.posts;
import com.example.demo.repos.postsRepos;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.Optional;

@Controller
public class PostsController {

    @Autowired
    private postsRepos PostsRepos;

    @GetMapping("/posts")
    public String postsSelect(Model model){

        Iterable<posts> posts = PostsRepos.findAll();
        model.addAttribute("posts", posts);
        System.out.println(posts);

        return "postsSelect";
    }

    @GetMapping("posts/create/")
    public String postsCreate(Model model){

        return "postsCreate";
    }

    @PostMapping("posts/create/")
    public String postsCreateAction(@RequestParam String position, Model model){

        posts po = new posts(position);
        PostsRepos.save(po);

        return "redirect:/posts";
    }

    @GetMapping("posts/edit/{id}")
    public String postsEdit(Model model, @PathVariable (value = "id") Long id){

        Optional<posts> postOp = PostsRepos.findById(id);
        ArrayList<posts> res = new ArrayList<>();
        postOp.ifPresent(res::add);
        model.addAttribute("posts",res);

        return "postsEdit";
    }

    @PostMapping("posts/edit/{id}")
    public String postsEditAction(Model model, @PathVariable (value = "id") Long id, @RequestParam String position){

        posts po = PostsRepos.findById(id).orElseThrow();
        po.setPosition(position);
        PostsRepos.save(po);

        return "redirect:/posts";
    }

    @GetMapping("/posts/delete/{id}")
    public String postsDelete(Model model, @PathVariable (value = "id") Long id){

        Optional<posts> postOp = PostsRepos.findById(id);
        ArrayList<posts> res = new ArrayList<>();
        postOp.ifPresent(res::add);
        model.addAttribute("posts",res);

        return "postsDelete";
    }
    @PostMapping("/posts/delete/{id}")
    public String postsDeleteAction(Model model, @PathVariable(value = "id") Long id){

        PostsRepos.deleteById(id);

        return "redirect:/posts";
    }

}



























