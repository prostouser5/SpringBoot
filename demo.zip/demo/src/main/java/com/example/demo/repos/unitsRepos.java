package com.example.demo.repos;

import com.example.demo.models.Units;
import org.springframework.data.repository.CrudRepository;

public interface unitsRepos extends CrudRepository<Units, Long> {
}
