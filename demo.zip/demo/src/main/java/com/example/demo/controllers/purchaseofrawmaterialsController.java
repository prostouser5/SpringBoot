package com.example.demo.controllers;

import com.example.demo.models.*;
import com.example.demo.repos.purchaseofrawmaterialsRepos;
import com.example.demo.repos.rawmaterialsRepos;
import com.example.demo.models.budget;
import com.example.demo.models.rawmaterialls;
import com.example.demo.repos.budgetRepos;
import com.example.demo.repos.employeeRepos;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Optional;

@Controller
public class purchaseofrawmaterialsController {

    @Autowired
    private purchaseofrawmaterialsRepos PurchaseofrawmaterialsRepos;
    @Autowired
    private employeeRepos PurchaseofrawmaterialsEmployeesRepos;
    @Autowired
    private rawmaterialsRepos PurchaseofrawmaterialsRawRepos;
    @Autowired
    private budgetRepos PurchBudgetRepos;

    @GetMapping("/purchaseofrawmaterials")
    public String purchaseofrawmaterialsSelect(Model model){

        Iterable<purchaseofrawmaterials> purchaseofrawmaterials = PurchaseofrawmaterialsRepos.findAll();
        model.addAttribute("purchaseofrawmaterials", purchaseofrawmaterials);
        System.out.println(purchaseofrawmaterials);

        return "purchaseofrawmaterialsSelect";
    }

    @GetMapping("/purchaseofrawmaterials/create")
    public String purchaseofrawmaterialsCreate(Model model){
        ArrayList<employees> finprodrepos = new ArrayList<>();
        Iterable<employees> finrpoditer = PurchaseofrawmaterialsEmployeesRepos.findAll();
        for (employees e:finrpoditer) {
            finprodrepos.add(e);
        }
        model.addAttribute("employeesList",finprodrepos);

        ArrayList<rawmaterialls> rawmatrepos = new ArrayList<>();
        Iterable<rawmaterialls> rawmatiter = PurchaseofrawmaterialsRawRepos.findAll();
        for (rawmaterialls e:rawmatiter) {
            rawmatrepos.add(e);
        }
        model.addAttribute("rawList",rawmatrepos);

        return "purchaseofrawmaterialsCreate";
    }

    @PostMapping("/purchaseofrawmaterials/create")
    public String purchaseofrawmaterialsCreateAction(Model model, @RequestParam employees employees, @RequestParam rawmaterialls rawmaterial,
                                                     @RequestParam String amount, @RequestParam String summa, @RequestParam Date datee) {

        Iterable<budget> budIter = PurchBudgetRepos.findAll();

        for (budget bu : budIter) {
            if (bu.getSumOfBudget() >= Long.parseLong(summa)) {
                bu.MinusBudget(Long.parseLong(summa));

            } else {
                model.addAttribute("ErrorMessage", "Not enough budget!");
                return "ErrorsPage";
            }
        }
        rawmaterialls raw = PurchaseofrawmaterialsRawRepos.findById(rawmaterial.getId()).orElseThrow();
        raw.PlusSum(summa);
        raw.PlusAmount(amount);


        purchaseofrawmaterials pr = new purchaseofrawmaterials(rawmaterial, amount, summa, datee, employees);
        PurchaseofrawmaterialsRepos.save(pr);
        return "redirect:/purchaseofrawmaterials";

    }





    @GetMapping("purchaseofrawmaterials/edit/{id}")
    public String purchaseofrawmaterialsCEdit(Model model, @PathVariable(value = "id") Long id){
        ArrayList<employees> finprodrepos = new ArrayList<>();
        Iterable<employees> finrpoditer = PurchaseofrawmaterialsEmployeesRepos.findAll();
        for (employees e:finrpoditer) {
            finprodrepos.add(e);
        }
        model.addAttribute("employeesList",finprodrepos);

        ArrayList<rawmaterialls> rawmatrepos = new ArrayList<>();
        Iterable<rawmaterialls> rawmatiter = PurchaseofrawmaterialsRawRepos.findAll();
        for (rawmaterialls e:rawmatiter) {
            rawmatrepos.add(e);
        }
        model.addAttribute("rawList",rawmatrepos);

        Optional<purchaseofrawmaterials> finOp = PurchaseofrawmaterialsRepos.findById(id);
        ArrayList<purchaseofrawmaterials> res = new ArrayList<>();
        finOp.ifPresent(res::add);
        model.addAttribute("purchaseofrawmaterials", res);


        return "purchaseofrawmaterialsEdit";
    }

    @PostMapping("/purchaseofrawmaterials/edit/{id}")
    public String purchaseofrawmaterialsCEditAction(Model model, @PathVariable(value = "id") Long id, @RequestParam employees employee,
                                        @RequestParam rawmaterialls rawmaterial, @RequestParam String amount, @RequestParam String summa, @RequestParam Date datee){

        purchaseofrawmaterials ing = PurchaseofrawmaterialsRepos.findById(id).orElseThrow();

        Iterable<budget> budIter = PurchBudgetRepos.findAll();
        for (budget bu:budIter) {
            if ((bu.getSumOfBudget() + Integer.parseInt(ing.getSumma())) >= Long.parseLong(summa)) {
                bu.MinusBudget(Long.parseLong(summa));

            } else {
                model.addAttribute("ErrorMessage", "Not enough budget!");
                return "ErrorsPage";
            }
        }
        for (budget bu:budIter) {
            bu.PlusBudget(Long.parseLong(ing.getSumma()));
        }


        rawmaterialls raw = PurchaseofrawmaterialsRawRepos.findById(rawmaterial.getId()).orElseThrow();
        if (Integer.parseInt(raw.getSumma()) >= Integer.parseInt(ing.getSumma()) &&
                Integer.parseInt(raw.getAmount()) >= Integer.parseInt(ing.getAmount())) {
            raw.MinusSum(ing.getSumma());
            raw.MinusAmount(ing.getAmount());
            System.out.println(ing.getSumma()+" "+ing.getAmount());
        }else{
            model.addAttribute("ErrorMessage", "Not enough raw materials!");
            return "ErrorsPage";
        }
        raw.PlusAmount(amount);
        raw.PlusSum(summa);
        System.out.println(amount+" "+summa);




        ing.setSumma(summa);
        ing.setRawmaterial(rawmaterial);
        ing.setAmount(amount);
        ing.setEmployee(employee);
        ing.setDatee(datee);
        PurchaseofrawmaterialsRepos.save(ing);

        return "redirect:/purchaseofrawmaterials";
    }

    @GetMapping("purchaseofrawmaterials/delete/{id}")
    public String purchaseofrawmaterialsDelete(Model model, @PathVariable(value = "id") Long id){

        Optional<purchaseofrawmaterials> finOp = PurchaseofrawmaterialsRepos.findById(id);
        ArrayList<purchaseofrawmaterials> res = new ArrayList<>();
        finOp.ifPresent(res::add);
        model.addAttribute("purchaseofrawmaterials", res);

        return "purchaseofrawmaterialsDelete";
    }

    @PostMapping("purchaseofrawmaterials/delete/{id}")
    public String purchaseofrawmaterialsDeleteAction(Model model, @PathVariable(value = "id") Long id){
        purchaseofrawmaterials pur =  PurchaseofrawmaterialsRepos.findById(id).orElseThrow();
        String sum = pur.getSumma();
        Iterable<budget> budIter = PurchBudgetRepos.findAll();
        for (budget bu:budIter) {
            bu.PlusBudget(Long.parseLong(sum));
        }

        rawmaterialls raw = PurchaseofrawmaterialsRawRepos.findById(pur.getRawmaterial().getId()).orElseThrow();
        if (Integer.parseInt(raw.getSumma()) >= Integer.parseInt(pur.getSumma()) &&
                Integer.parseInt(raw.getAmount()) >= Integer.parseInt(pur.getAmount())){
                raw.MinusAmount(pur.getSumma());
                raw.MinusSum(pur.getAmount());
        }else{
            model.addAttribute("ErrorMessage", "Not enough raw materials!");
            return "ErrorsPage";
        }


        PurchaseofrawmaterialsRepos.deleteById(id);

        return "redirect:/purchaseofrawmaterials";
    }

}


