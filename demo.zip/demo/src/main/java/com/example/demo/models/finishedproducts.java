package com.example.demo.models;

import javax.persistence.*;

@Entity
public class finishedproducts {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long Id;

    private String finishedproducts_title, summa, amount;

    @ManyToOne
    @JoinColumn(name = "unit")
    private Units unit;

    public finishedproducts(String finishedproducts_title, String summa, String amount, com.example.demo.models.Units units) {
        this.finishedproducts_title = finishedproducts_title;
        this.summa = summa;
        this.amount = amount;
        this.unit = units;
    }

    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }

    public String getFinishedproducts_title() {
        return finishedproducts_title;
    }

    public void setFinishedproducts_title(String finishedproducts_title) {
        this.finishedproducts_title = finishedproducts_title;
    }

    public String getSumma() {
        return summa;
    }

    public void setSumma(String summa) {
        this.summa = summa;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public com.example.demo.models.Units getUnits() {
        return unit;
    }

    public void setUnits(com.example.demo.models.Units units) {
        this.unit = units;
    }

    public finishedproducts() {
    }


    public void PlusAmount(String amount){
        int a = Integer.parseInt(amount);
        int b = Integer.parseInt(this.amount);
        int c = b+a;
        this.amount = c+"";
    }
    public void MinusAmount(String amount){
        int a = Integer.parseInt(amount);
        int b = Integer.parseInt(this.amount);
        int c = b-a;
        this.amount = c+"";
    }
    public void MinusSum(String summa){
        int a = Integer.parseInt(summa);
        int b = Integer.parseInt(this.summa);
        int c = b-a;
        this.summa = c+"";
    }

    public void PlusSum(String summa){
        int a = Integer.parseInt(summa);
        int b = Integer.parseInt(this.summa);
        int c = b+a;
        this.summa = c+"";
    }
}
