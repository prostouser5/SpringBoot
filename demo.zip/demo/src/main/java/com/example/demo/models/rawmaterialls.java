package com.example.demo.models;

import javax.persistence.*;

@Entity
public class rawmaterialls {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long Id;

    private String raw_title;

    @ManyToOne
    @JoinColumn(name = "unit")
    private Units unit;

    private String summa;

    private String amount;

    public rawmaterialls() {
    }

    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }

    public String getRaw_title() {
        return raw_title;
    }

    public void setRaw_title(String raw_title) {
        this.raw_title = raw_title;
    }

    public Units getUnits() {
        return unit;
    }

    public void setUnits(Units units) {
        this.unit = units;
    }

    public String getSumma() {
        return summa;
    }

    public void setSumma(String summa) {
        this.summa = summa;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public rawmaterialls(String raw_title, Units units, String summa, String amount) {
        this.raw_title = raw_title;
        this.unit = units;
        this.summa = summa;
        this.amount = amount;
    }
    public void PlusSum(String sum){
        int a = Integer.parseInt(sum);
        int b = Integer.parseInt(this.summa);
        int c = b+a;
        this.summa = c+"";
    }
    public void MinusSum(String sum){
        int a = Integer.parseInt(sum);
        int b = Integer.parseInt(this.summa);
        int c = b-a;
        this.summa = c+"";
    }
    public void PlusAmount(String amount){
        int a = Integer.parseInt(amount);
        int b = Integer.parseInt(this.amount);
        int c = b+a;
        this.amount = c+"";
    }
    public void MinusAmount(String amount){
        int a = Integer.parseInt(amount);
        int b = Integer.parseInt(this.amount);
        int c = b-a;
        this.amount = c+"";
    }


}
