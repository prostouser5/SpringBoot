package com.example.demo.controllers;

import com.example.demo.models.Units;

import com.example.demo.models.employees;
import com.example.demo.models.posts;
import com.example.demo.models.rawmaterialls;
import com.example.demo.repos.rawmaterialsRepos;
import com.example.demo.repos.unitsRepos;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.Optional;

@Controller
public class rawmaterialsController {
    @Autowired
    private rawmaterialsRepos RawmaterialsRepos;

    @Autowired
    private unitsRepos rawUnitRepos;

    @GetMapping("/rawmaterials")
    public String rawmaterialsSelect(Model model){

        Iterable<rawmaterialls> rawmaterialls = RawmaterialsRepos.findAll();
        model.addAttribute("rawmaterialls", rawmaterialls);
        System.out.println(rawmaterialls);

        return "rawmaterialsSelect";
    }

    @GetMapping("rawmaterial/create")
    public String rawmaterialsCreate(Model model){

        ArrayList<Units> es = new ArrayList<>();
        Iterable<Units> empList = rawUnitRepos.findAll();
        for (Units e:empList) {
            es.add(e);
        }

        model.addAttribute("es", es);
        return "rawmaterialCreate";
    }

    @PostMapping("rawmaterial/create")
    public String rawmaterialsCreateAction(Model model, @RequestParam String raw_title, @RequestParam Units unit, @RequestParam String summa, @RequestParam String amount){

        rawmaterialls ra = new rawmaterialls(raw_title, unit, summa, amount);
        RawmaterialsRepos.save(ra);



        return "redirect:/rawmaterials";
    }

    @GetMapping("rawmaterial/edit/{id}")
    public String rawmaterialsEdit(Model model, Model mod, @PathVariable(value = "id") Long id){
        ArrayList<Units> es = new ArrayList<>();
        Iterable<Units> empList = rawUnitRepos.findAll();
        for (Units e:empList) {
            es.add(e);
        }

        mod.addAttribute("es", es);

        Optional<rawmaterialls> employeesOp = RawmaterialsRepos.findById(id);
        ArrayList<rawmaterialls> res = new ArrayList<>();
        employeesOp.ifPresent(res::add);
        model.addAttribute("rawmaterialls", res);

        return "rawmaterialsEdit";
    }

    @PostMapping("rawmaterial/edit/{id}")
    public String rawmaterialsEditAction(Model model, @PathVariable(value = "id") Long id, @RequestParam String raw_title, @RequestParam Units unit, @RequestParam String summa, @RequestParam String amount){

        rawmaterialls ra = RawmaterialsRepos.findById(id).orElseThrow();
        ra.setRaw_title(raw_title);
        ra.setUnits(unit);
        ra.setSumma(summa);
        ra.setAmount(amount);
        RawmaterialsRepos.save(ra);
        return "redirect:/rawmaterials";
    }

    @GetMapping("rawmaterial/delete/{id}")
    public String rawmaterialsDelete(Model model, @PathVariable(value = "id") Long id){
        Optional<rawmaterialls> raw = RawmaterialsRepos.findById(id);
        ArrayList<rawmaterialls> res = new ArrayList<>();
        raw.ifPresent(res::add);
        model.addAttribute("rawmaterialls",res);


        return "rawmaterialsDelete";
    }
    @PostMapping("rawmaterial/delete/{id}")
    public String rawmaterialsDeleteAction(Model model, @PathVariable (value = "id") Long id){

        RawmaterialsRepos.deleteById(id);

        return  "redirect:/rawmaterials";
    }




}
