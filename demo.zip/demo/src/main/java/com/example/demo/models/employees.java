package com.example.demo.models;

import javax.persistence.*;

import com.example.demo.models.posts;

@Entity
public class employees {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long Id;

    private String name, salary,address;

    @ManyToOne
    @JoinColumn(name = "position")
    private posts position;

    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSalary() {
        return salary;
    }

    public void setSalary(String salary) {
        this.salary = salary;
    }

    public String getAddress() {
        return address;
    }


    public employees(String name, String salary, String address, com.example.demo.models.posts posts) {
        this.name = name;
        this.salary = salary;
        this.address = address;
        this.position = posts;
    }

    public com.example.demo.models.posts getPosts() {
        return position;
    }

    public void setPosts(com.example.demo.models.posts posts) {
        this.position = posts;
    }

    public void setAddress(String address) {
        this.address = address;
    }





    public employees() {
    }
}
