package com.example.demo.repos;

import com.example.demo.models.posts;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface postsRepos extends CrudRepository<posts, Long> {
}
