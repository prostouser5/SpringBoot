package com.example.demo.controllers;


import com.example.demo.models.production;
import com.example.demo.repos.productionRepos;
import com.example.demo.models.finishedproducts;
import com.example.demo.repos.ingredientsRepos;
import com.example.demo.models.ingredients;
import com.example.demo.repos.finishedproductsRepos;
import com.example.demo.models.rawmaterialls;
import com.example.demo.repos.rawmaterialsRepos;
import com.example.demo.models.employees;
import com.example.demo.repos.employeeRepos;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Optional;

@Controller
public class productionsController {

    @Autowired
    private rawmaterialsRepos ProductionRawRepos;
    @Autowired
    private productionRepos ProductionRepos;

    @Autowired
    private employeeRepos ProductionEmpRepos;

    @Autowired
    private ingredientsRepos ProductionINgRepos;

    @Autowired
    private finishedproductsRepos ProductionFinRepos;

    @GetMapping("/production")
    public String productionSelect(Model model){

        Iterable<production> production = ProductionRepos.findAll();
        model.addAttribute("production", production);
        System.out.println(production);

        return "productionSelect";
    }

    @GetMapping("/production/create")
    public String productionCreate(Model model){
        ArrayList<employees> finprodrepos = new ArrayList<>();
        Iterable<employees> finrpoditer = ProductionEmpRepos.findAll();
        for (employees e:finrpoditer) {
            finprodrepos.add(e);
        }
        model.addAttribute("employeesList",finprodrepos);

        ArrayList<finishedproducts> rawmatrepos = new ArrayList<>();
        Iterable<finishedproducts> rawmatiter = ProductionFinRepos.findAll();
        for (finishedproducts e:rawmatiter) {
            rawmatrepos.add(e);
        }
        model.addAttribute("productList",rawmatrepos);

        return "productionCreate";
    }

    @PostMapping("/production/create")
    public String productionCreateAction(Model model, @RequestParam employees employee, @RequestParam finishedproducts product,
                                             @RequestParam String amount, @RequestParam String summa, @RequestParam Date datee){

        finishedproducts fin = ProductionFinRepos.findById(product.getId()).orElseThrow();
        fin.PlusAmount(amount);
        fin.PlusSum(summa);


        Iterable<ingredients> ingrd = ProductionINgRepos.findAll();
        ArrayList<ingredients> ind = new ArrayList<>();
        for (ingredients inf:ingrd) {
            ind.add(inf);
        }

        rawmaterialls raws = new rawmaterialls();
        for (int i = 0; i < ind.size(); i++) {
            if (product.getId() == ind.get(i).getProduct().getId()){
                raws = ind.get(i).getRawmaterial();
                if ((Integer.parseInt(amount)*Integer.parseInt(ind.get(i).getAmount()) <= Integer.parseInt(raws.getAmount())) &&
                        Integer.parseInt(summa)*Integer.parseInt(ind.get(i).getSumma()) <= Integer.parseInt(raws.getSumma())){
                    raws.MinusAmount(Integer.parseInt(amount)*Integer.parseInt(ind.get(i).getAmount())+"");
                    raws.MinusSum(Integer.parseInt(summa)*Integer.parseInt(ind.get(i).getSumma())+"");

                }else {
                    model.addAttribute("ErrorMessage", "Not enough raw materials!");
                    return "ErrorsPage";
                }
            }

        }



        production pr = new production(amount, summa, datee, product, employee);
        ProductionRepos.save(pr);
        return "redirect:/production";
    }


    @GetMapping("production/edit/{id}")
    public String productionCEdit(Model model, @PathVariable(value = "id") Long id){
        ArrayList<employees> finprodrepos = new ArrayList<>();
        Iterable<employees> finrpoditer = ProductionEmpRepos.findAll();
        for (employees e:finrpoditer) {
            finprodrepos.add(e);
        }
        model.addAttribute("employeesList",finprodrepos);

        ArrayList<finishedproducts> rawmatrepos = new ArrayList<>();
        Iterable<finishedproducts> rawmatiter = ProductionFinRepos.findAll();
        for (finishedproducts e:rawmatiter) {
            rawmatrepos.add(e);
        }
        model.addAttribute("productList",rawmatrepos);

        Optional<production> finOp = ProductionRepos.findById(id);
        ArrayList<production> res = new ArrayList<>();
        finOp.ifPresent(res::add);
        model.addAttribute("production", res);


        return "productionEdit";
    }

    @PostMapping("/production/edit/{id}")
    public String productionEditAction(Model model, @PathVariable(value = "id") Long id, @RequestParam employees employee,
                                           @RequestParam finishedproducts product, @RequestParam String amount, @RequestParam String summa, @RequestParam Date datee){

        production ing = ProductionRepos.findById(id).orElseThrow();
        finishedproducts fin = ProductionFinRepos.findById(product.getId()).orElseThrow();
        if ((Integer.parseInt(fin.getAmount()) + Integer.parseInt(ing.getAmount())) >= Integer.parseInt(amount) &&
                (Integer.parseInt(fin.getSumma()) + Integer.parseInt(ing.getSumma())) >= Integer.parseInt(summa)){
            fin.MinusSum(ing.getSumma());
            fin.MinusAmount(ing.getAmount());
            fin.PlusSum(summa);
            fin.PlusAmount(amount);
        }else{
            model.addAttribute("ErrorMessage", "Not enough finished products!");
            return "ErrorsPage";
        }


        Iterable<ingredients> ingrd = ProductionINgRepos.findAll();
        ArrayList<ingredients> ind = new ArrayList<>();
        for (ingredients inf:ingrd) {
            ind.add(inf);
        }

        production pro = ProductionRepos.findById(id).orElseThrow();

        int amountt, indAmountt, rawAmount, summaa, rawSumma, indSumma;

        rawmaterialls raw = new rawmaterialls();
        for (int i = 0; i < ind.size(); i++) {
            if (ind.get(i).getProduct().getId() == pro.getProduct().getId()){
                raw = ind.get(i).getRawmaterial();

                amountt = Integer.parseInt(amount);
                indAmountt = Integer.parseInt(ind.get(i).getAmount());
                rawAmount = Integer.parseInt(raw.getAmount());
                summaa = Integer.parseInt(summa);
                rawSumma = Integer.parseInt(raw.getSumma());
                indSumma = Integer.parseInt(ind.get(i).getSumma());

                if ((amountt * indAmountt <= rawAmount) &&
                                (summaa * indSumma) <= rawSumma){

                    raw.PlusAmount(Integer.parseInt(pro.getAmount()) * Integer.parseInt(ind.get(i).getAmount())+"");
                    raw.PlusSum(Integer.parseInt(pro.getSumma()) * Integer.parseInt(ind.get(i).getSumma())+"");
                    raw.MinusAmount(Integer.parseInt(amount)*Integer.parseInt(ind.get(i).getAmount())+"");
                    raw.MinusSum(Integer.parseInt(summa)*Integer.parseInt(ind.get(i).getSumma())+"");
                    System.out.println("Заработала!");
                }else{
                    model.addAttribute("ErrorMessage", "Not enough raw materials!");
                    return "ErrorsPage";
                }

            }else System.out.println("Не добавилось!");

        }






        ing.setSumma(summa);
        ing.setProduct(product);
        ing.setAmount(amount);
        ing.setEmployee(employee);
        ing.setDatee(datee);
        ProductionRepos.save(ing);

        return "redirect:/production";
    }

    @GetMapping("production/delete/{id}")
    public String productionDelete(Model model, @PathVariable(value = "id") Long id){

        Optional<production> finOp = ProductionRepos.findById(id);
        ArrayList<production> res = new ArrayList<>();
        finOp.ifPresent(res::add);
        model.addAttribute("production", res);

        return "productionDelete";
    }

    @PostMapping("production/delete/{id}")
    public String productionDeleteAction(Model model, @PathVariable(value = "id") Long id){


        production ing = ProductionRepos.findById(id).orElseThrow();
        finishedproducts fin = ProductionFinRepos.findById(ing.getProduct().getId()).orElseThrow();
        if (Integer.parseInt(fin.getSumma()) >= Integer.parseInt(ing.getSumma()) &&
        Integer.parseInt(fin.getAmount()) >= Integer.parseInt(ing.getAmount())){
            fin.MinusAmount(ing.getAmount());
            fin.MinusSum(ing.getSumma());
        }



        Iterable<ingredients> ingrd = ProductionINgRepos.findAll();
        ArrayList<ingredients> ind = new ArrayList<>();
        for (ingredients inf:ingrd) {
            ind.add(inf);
        }

        rawmaterialls raw = new rawmaterialls();
        for (int i = 0; i < ind.size(); i++) {
            if (ing.getProduct().getId() == ind.get(i).getProduct().getId()){
                raw = ind.get(i).getRawmaterial();
                raw.PlusAmount(Integer.parseInt(ing.getAmount()) * Integer.parseInt(ind.get(i).getAmount())+"");
                raw.PlusSum(Integer.parseInt(ing.getSumma()) * Integer.parseInt(ind.get(i).getSumma())+"");
            }

        }



        ProductionRepos.deleteById(id);
        return "redirect:/production";
    }



}

