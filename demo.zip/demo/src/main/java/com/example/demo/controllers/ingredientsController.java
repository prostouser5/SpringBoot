package com.example.demo.controllers;

import com.example.demo.models.ingredients;
import com.example.demo.models.finishedproducts;
import com.example.demo.models.rawmaterialls;
import com.example.demo.repos.ingredientsRepos;
import com.example.demo.repos.finishedproductsRepos;
import com.example.demo.repos.rawmaterialsRepos;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.Optional;

@Controller
public class ingredientsController {

    @Autowired
    private ingredientsRepos IngredientsRepos;

    @Autowired
    private finishedproductsRepos IngredientsFinRepos;

    @Autowired
    private rawmaterialsRepos IngredientsRawRepos;

    @GetMapping("/ingredients")
    public String ingredientsSelect(Model model){

        Iterable<ingredients> ingredients = IngredientsRepos.findAll();
        model.addAttribute("ingredients", ingredients);
        System.out.println(ingredients);

        return "ingredientsSelect";
    }

    @GetMapping("/ingredients/create")
    public String ingredientsCreate(Model model, Model model2){
        ArrayList<finishedproducts> finprodrepos = new ArrayList<>();
        Iterable<finishedproducts> finrpoditer = IngredientsFinRepos.findAll();
        for (finishedproducts e:finrpoditer) {
            finprodrepos.add(e);
        }
        model.addAttribute("productList",finprodrepos);

        ArrayList<rawmaterialls> rawmatrepos = new ArrayList<>();
        Iterable<rawmaterialls> rawmatiter = IngredientsRawRepos.findAll();
        for (rawmaterialls e:rawmatiter) {
            rawmatrepos.add(e);
        }
        model.addAttribute("rawList",rawmatrepos);

        return "ingredientsCreate";
    }

    @PostMapping("/ingredients/create")
    public String ingredientsCreateAction(Model model, @RequestParam finishedproducts product, @RequestParam rawmaterialls rawmaterial, @RequestParam String amount, @RequestParam String summa ){
        ingredients ing = new ingredients(product, rawmaterial, amount, summa);
        ing.setProduct(product);
        ing.setRawmaterial(rawmaterial);
        ing.setAmount(amount);
        ing.setSumma(summa);
        IngredientsRepos.save(ing);
        return "redirect:/ingredients";
    }

    @GetMapping("/ingredients/edit/{id}")
    public String ingredientsEdit(Model model, @PathVariable(value = "id") Long id){
        ArrayList<finishedproducts> finprodrepos = new ArrayList<>();
        Iterable<finishedproducts> finrpoditer = IngredientsFinRepos.findAll();
        for (finishedproducts e:finrpoditer) {
            finprodrepos.add(e);
        }
        model.addAttribute("productList",finprodrepos);

        ArrayList<rawmaterialls> rawmatrepos = new ArrayList<>();
        Iterable<rawmaterialls> rawmatiter = IngredientsRawRepos.findAll();
        for (rawmaterialls e:rawmatiter) {
            rawmatrepos.add(e);
        }
        model.addAttribute("rawList",rawmatrepos);

        Optional<ingredients> finOp = IngredientsRepos.findById(id);
        ArrayList<ingredients> res = new ArrayList<>();
        finOp.ifPresent(res::add);
        model.addAttribute("ingredients", res);


        return "ingredientsEdit";
    }

    @PostMapping("/ingredients/edit/{id}")
    public String ingredientsEditAction(Model model, @PathVariable(value = "id") Long id, @RequestParam finishedproducts product ,
    @RequestParam rawmaterialls rawmaterial, @RequestParam String amount, @RequestParam String summa){

        ingredients ing = IngredientsRepos.findById(id).orElseThrow();
        ing.setProduct(product);
        ing.setRawmaterial(rawmaterial);
        ing.setAmount(amount);
        ing.setSumma(summa);
        IngredientsRepos.save(ing);

        return "redirect:/ingredients";
    }


    @GetMapping("ingredients/delete/{id}")
    public String ingredientsDelete(Model model, Model model2, @PathVariable(value = "id") Long id){

        Optional<ingredients> finOp = IngredientsRepos.findById(id);
        ArrayList<ingredients> res = new ArrayList<>();
        finOp.ifPresent(res::add);
        model.addAttribute("ingredients", res);

        return "ingredientsDelete";
    }

    @PostMapping("ingredients/delete/{id}")
    public String ingredientsDeleteAction(Model model, @PathVariable(value = "id") Long id){
        IngredientsRepos.deleteById(id);
        return "redirect:/ingredients";
    }
}


















