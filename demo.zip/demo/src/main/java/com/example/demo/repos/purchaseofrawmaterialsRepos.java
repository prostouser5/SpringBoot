package com.example.demo.repos;


import com.example.demo.models.purchaseofrawmaterials;
import org.springframework.data.repository.CrudRepository;

public interface purchaseofrawmaterialsRepos extends CrudRepository<purchaseofrawmaterials, Long> {
}
