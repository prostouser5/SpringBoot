package com.example.demo.repos;

import com.example.demo.models.production;
import org.springframework.data.repository.CrudRepository;

public interface productionRepos extends CrudRepository<production, Long> {
}
