package com.example.demo.controllers;


import com.example.demo.models.budget;
import com.example.demo.models.posts;
import com.example.demo.repos.budgetRepos;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.Optional;

@Controller
public class BudgetController {


    @Autowired
    private budgetRepos BudgetRepos;


    @GetMapping("/budget")
    public String BudgetSelect(Model model){

        Iterable<budget> budgets = BudgetRepos.findAll();
        model.addAttribute("budgets", budgets);
        System.out.println(budgets);
        return "budgetSelect";
    }

    @GetMapping("/budget/edit/{id}")
    public String AddBudget(Model model, @PathVariable(value = "id") Long id){

        Optional<budget> postOp = BudgetRepos.findById(id);
        ArrayList<budget> res = new ArrayList<>();
        postOp.ifPresent(res::add);
        model.addAttribute("budget",res);


        return "budgetedit";
    }


    @PostMapping("/budget/edit/{id}")
    public String AddBudgetAction(@RequestParam Long SumOfBudget,
                                  @PathVariable(value = "id") Long id){



            budget bud = BudgetRepos.findById(id).orElseThrow();
            bud.setSumOfBudget(SumOfBudget);
            BudgetRepos.save(bud);



        return "redirect:/budget";
    }
}
