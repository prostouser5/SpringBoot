package com.example.demo.repos;

import com.example.demo.models.finishedproducts;
import org.springframework.data.repository.CrudRepository;

public interface finishedproductsRepos extends CrudRepository<finishedproducts, Long> {
}
