package com.example.demo.models;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

@Entity
public class budget {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long Id;

    private Long SumOfBudget;

    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        this.Id = id;
    }

    public Long getSumOfBudget() {
        return SumOfBudget;
    }

    public void setSumOfBudget(Long sumOfBudget) {
        this.SumOfBudget = sumOfBudget;
    }

    public budget() {
    }

    public budget(Long sumOfBudget) {
        this.SumOfBudget = sumOfBudget;
    }

    public void PlusBudget(Long sum){
        this.SumOfBudget+=sum;
    }

    public void MinusBudget(Long sum){
        this.SumOfBudget-=sum;
    }
}
