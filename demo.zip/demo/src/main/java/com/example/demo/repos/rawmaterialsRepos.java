package com.example.demo.repos;

import com.example.demo.models.rawmaterialls;
import org.springframework.data.repository.CrudRepository;

public interface rawmaterialsRepos extends CrudRepository<rawmaterialls, Long> {
}
