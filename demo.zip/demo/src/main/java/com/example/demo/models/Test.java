package com.example.demo.models;

public class Test {
    String name;
    posts posts;
    String salary;
    String address;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public com.example.demo.models.posts getPosts() {
        return posts;
    }

    public void setPosts(com.example.demo.models.posts posts) {
        this.posts = posts;
    }

    public String getSalary() {
        return salary;
    }

    public Test() {
    }

    public void setSalary(String salary) {
        this.salary = salary;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

}
