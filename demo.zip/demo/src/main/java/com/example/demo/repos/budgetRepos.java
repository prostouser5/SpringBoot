package com.example.demo.repos;

import com.example.demo.models.budget;
import org.springframework.data.repository.CrudRepository;

public interface budgetRepos extends CrudRepository<budget, Long> {

}
