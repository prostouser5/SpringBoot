package com.example.demo.models;

import javax.persistence.*;
import java.util.Date;

@Entity
public class purchaseofrawmaterials {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long Id;


    @ManyToOne
    @JoinColumn(name = "rawmaterial")
    private rawmaterialls rawmaterial;

    private String amount, summa;

    private Date datee;

    @ManyToOne
    @JoinColumn(name = "employee")
    private employees employee;

    public purchaseofrawmaterials(rawmaterialls rawmaterial, String amount, String summa, Date datee, employees employee) {
        this.rawmaterial = rawmaterial;
        this.amount = amount;
        this.summa = summa;
        this.datee = datee;
        this.employee = employee;
    }

    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }

    public rawmaterialls getRawmaterial() {
        return rawmaterial;
    }

    public void setRawmaterial(rawmaterialls rawmaterial) {
        this.rawmaterial = rawmaterial;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getSumma() {
        return summa;
    }

    public void setSumma(String summa) {
        this.summa = summa;
    }

    public Date getDatee() {
        return datee;
    }

    public void setDatee(Date datee) {
        this.datee = datee;
    }

    public employees getEmployee() {
        return employee;
    }

    public void setEmployee(employees employee) {
        this.employee = employee;
    }

    public purchaseofrawmaterials() {
    }
}
