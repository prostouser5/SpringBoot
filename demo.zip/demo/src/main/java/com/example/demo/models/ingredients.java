package com.example.demo.models;

import javax.persistence.*;

@Entity
public class ingredients {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long Id;

    @ManyToOne
    @JoinColumn(name = "product")
    private finishedproducts product;

    @ManyToOne
    @JoinColumn(name = "rawmaterial")
    private rawmaterialls rawmaterial;

    private String amount;
    private String summa;

    public ingredients(finishedproducts product, rawmaterialls rawmaterial, String amount, String summa) {
        this.product = product;
        this.rawmaterial = rawmaterial;
        this.amount = amount;
        this.summa = summa;
    }

    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }

    public finishedproducts getProduct() {
        return product;
    }

    public void setProduct(finishedproducts product) {
        this.product = product;
    }

    public rawmaterialls getRawmaterial() {
        return rawmaterial;
    }

    public void setRawmaterial(rawmaterialls rawmaterial) {
        this.rawmaterial = rawmaterial;
    }

    public String getAmount() {
        return amount;
    }
    public String getSumma() {
        return summa;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }
    public void setSumma(String summa) {
        this.summa = summa;
    }

    public ingredients() {
    }
}
