package com.example.demo.repos;

import com.example.demo.models.ingredients;
import org.springframework.data.repository.CrudRepository;

public interface ingredientsRepos extends CrudRepository<ingredients, Long> {
}
