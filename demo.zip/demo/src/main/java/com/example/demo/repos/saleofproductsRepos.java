package com.example.demo.repos;

import com.example.demo.models.saleofproducts;
import org.springframework.data.repository.CrudRepository;

public interface saleofproductsRepos extends CrudRepository<saleofproducts, Long> {
}
