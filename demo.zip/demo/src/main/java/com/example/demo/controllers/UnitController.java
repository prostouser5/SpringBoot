package com.example.demo.controllers;

import com.example.demo.models.Units;
import com.example.demo.repos.unitsRepos;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.Optional;

@Controller
public class UnitController {

    @Autowired
    private unitsRepos UnitsRepos;

    @GetMapping("/units")
    public String unitsSelect(Model model){

        Iterable<Units> unit = UnitsRepos.findAll();
        model.addAttribute("units", unit);
        System.out.println(unit);

        return "unitsSelect";
    }


    @GetMapping("/unit/create/")
    public String unitsCreate(Model model){


        return "unitsCreate";
    }

    @PostMapping("/unit/create/")
    public String unitsCreateAction(@RequestParam String title, Model model){

        Units un = new Units(title);
        UnitsRepos.save(un);

        return "redirect:/units";
    }


    @GetMapping("/unit/delete/{id}")
    public String unitsDelete(@PathVariable(value = "id") Long id, Model model){

        Optional<Units> unit = UnitsRepos.findById(id);
        ArrayList<Units> res = new ArrayList<>();
        unit.ifPresent(res::add);
        model.addAttribute("units", res);

        return "unitsDelete";
    }

    @PostMapping("/unit/delete/{id}")
    public String unitsDeleteAction(@PathVariable(value = "id") Long id, Model model){

        UnitsRepos.deleteById(id);

        return "redirect:/units";
    }

    @GetMapping("/unit/edit/{id}")
    public String unitsEdit(@PathVariable(value = "id") Long id, Model model){

        Optional<Units> unitOp = UnitsRepos.findById(id);
        ArrayList<Units> res = new ArrayList<>();
        unitOp.ifPresent(res::add);
        model.addAttribute("units", res);
        return "unitsEdit";
    }
    @PostMapping("unit/edit/{id}")
    public String unitsEditAction(@PathVariable(value = "id") Long id, @RequestParam String title, Model model){

        Units un = UnitsRepos.findById(id).orElseThrow();
        un.setUnits_title(title);
        UnitsRepos.save(un);
        return "redirect:/units";
    }



}
