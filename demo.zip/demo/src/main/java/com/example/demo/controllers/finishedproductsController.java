package com.example.demo.controllers;

import com.example.demo.models.Units;
import com.example.demo.models.finishedproducts;
import com.example.demo.models.rawmaterialls;
import com.example.demo.repos.finishedproductsRepos;
import com.example.demo.repos.unitsRepos;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.Optional;

@Controller
public class finishedproductsController {

    @Autowired
    private finishedproductsRepos FinishedproductsRepos;

    @Autowired
    private unitsRepos finishUnitRepos;

    @GetMapping("/finishedproducts")
    public String finishedproductsSelect(Model model){

        Iterable<finishedproducts> finishedproducts = FinishedproductsRepos.findAll();
        model.addAttribute("finishedproducts", finishedproducts);
        System.out.println(finishedproducts);

        return "finishedproductsSelect";
    }

    @GetMapping("/finishedproducts/create")
    public String finishedproductsCreate(Model model){
        ArrayList<Units> es = new ArrayList<>();
        Iterable<Units> empList = finishUnitRepos.findAll();
        for (Units e:empList) {
            es.add(e);
        }

        model.addAttribute("es", es);

        return "finishedproductsCreate";
    }
    @PostMapping("finishedproducts/create")
    public String finishedproductsAction(Model model, @RequestParam String finishedproducts_title, @RequestParam Units unit, @RequestParam String summa,@RequestParam String amount){


        finishedproducts fin = new finishedproducts(finishedproducts_title, summa, amount, unit);
        FinishedproductsRepos.save(fin);


        return "redirect:/finishedproducts";
    }

    @GetMapping("finishedproducts/edit/{id}")
    public String finishedproductsEdit(Model model, @PathVariable(value = "id") Long id){

        ArrayList<Units> es = new ArrayList<>();
        Iterable<Units> empList = finishUnitRepos.findAll();
        for (Units e:empList) {
            es.add(e);
        }

        model.addAttribute("es", es);

        Optional<finishedproducts> finOp = FinishedproductsRepos.findById(id);
        ArrayList<finishedproducts> res = new ArrayList<>();
        finOp.ifPresent(res::add);
        model.addAttribute("finishedproducts", res);

        return "finishedproductsEdit";
    }

    @PostMapping("finishedproducts/edit/{id}")
    public String finishedproductsEditAction(Model model, @PathVariable(value = "id") Long id, @RequestParam String finishedproducts_title, @RequestParam Units unit, @RequestParam String summa, @RequestParam String amount) {

        finishedproducts fin = FinishedproductsRepos.findById(id).orElseThrow();
        fin.setFinishedproducts_title(finishedproducts_title);
        fin.setUnits(unit);
        fin.setSumma(summa);
        fin.setAmount(amount);
        FinishedproductsRepos.save(fin);
        return "redirect:/finishedproducts";
    }

    @GetMapping("finishedproducts/delete/{id}")
    public String finishedproductsDelete(Model model, @PathVariable(value = "id") Long id) {

        Optional<finishedproducts> finishOp = FinishedproductsRepos.findById(id);
        ArrayList<finishedproducts> res = new ArrayList<>();
        finishOp.ifPresent(res::add);
        model.addAttribute("finishedproducts",res);


        return "finishedproductsDelete";
    }

    @PostMapping("finishedproducts/delete/{id}")
    public String finishedproductsDeleteAction(Model model, @PathVariable(value = "id") Long id) {
        FinishedproductsRepos.deleteById(id);
        return "redirect:/finishedproducts";
    }

}
