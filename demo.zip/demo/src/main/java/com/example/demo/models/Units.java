package com.example.demo.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Units {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long Id;

    private String units_title;

    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }

    public String getUnits_title() {
        return units_title;
    }

    public void setUnits_title(String units_title) {
        this.units_title = units_title;
    }

    public Units(String units_title) {
        this.units_title = units_title;
    }

    public Units() {
    }
}
