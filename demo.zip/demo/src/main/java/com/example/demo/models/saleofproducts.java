package com.example.demo.models;

import javax.persistence.*;
import java.util.Date;

@Entity
public class saleofproducts {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long Id;

    private String amount;
        private String summa;

    private Date datee;

    @ManyToOne
    @JoinColumn(name = "product")
    private finishedproducts product;


    @ManyToOne
    @JoinColumn(name = "employee")
    private employees employee;


    public saleofproducts(String amount, String summa, Date datee, finishedproducts product, employees employee) {
        this.amount = amount;
        this.summa = summa;
        this.datee = datee;
        this.product = product;
        this.employee = employee;
    }

    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getSumma() {
        return summa;
    }

    public void setSumma(String summa) {
        this.summa = summa;
    }

    public Date getDatee() {
        return datee;
    }

    public void setDatee(Date datee) {
        this.datee = datee;
    }

    public finishedproducts getProduct() {
        return product;
    }

    public void setProduct(finishedproducts product) {
        this.product = product;
    }

    public employees getEmployee() {
        return employee;
    }

    public void setEmployee(employees employee) {
        this.employee = employee;
    }

    public saleofproducts() {
    }
}
