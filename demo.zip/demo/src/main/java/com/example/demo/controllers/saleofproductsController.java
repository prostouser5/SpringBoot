package com.example.demo.controllers;


import com.example.demo.models.*;
import com.example.demo.repos.saleofproductsRepos;
import com.example.demo.models.budget;
import com.example.demo.repos.budgetRepos;
import com.example.demo.repos.finishedproductsRepos;
import com.example.demo.repos.employeeRepos;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Optional;

@Controller
public class saleofproductsController {

    @Autowired
    private saleofproductsRepos SaleofproductsRepos;

    @Autowired
    private employeeRepos SaleofproductsEmpRepos;

    @Autowired
    private budgetRepos SaleBudgetRepos;

    @Autowired
    private finishedproductsRepos SaleofproductsFinRepos;

    @GetMapping("/saleofproducts")
    public String saleofproductsSelect(Model model){

        Iterable<saleofproducts> saleofproducts = SaleofproductsRepos.findAll();
        model.addAttribute("saleofproducts", saleofproducts);
        System.out.println(saleofproducts);

        return "saleofproductsSelect";
    }

    @GetMapping("/saleofproducts/create")
    public String saleofproductsCreate(Model model){
        ArrayList<employees> finprodrepos = new ArrayList<>();
        Iterable<employees> finrpoditer = SaleofproductsEmpRepos.findAll();
        for (employees e:finrpoditer) {
            finprodrepos.add(e);
        }
        model.addAttribute("employeesList",finprodrepos);

        ArrayList<finishedproducts> rawmatrepos = new ArrayList<>();
        Iterable<finishedproducts> rawmatiter = SaleofproductsFinRepos.findAll();
        for (finishedproducts e:rawmatiter) {
            rawmatrepos.add(e);
        }
        model.addAttribute("productList",rawmatrepos);

        return "saleofproductsCreate";
    }

    @PostMapping("/saleofproducts/create")
    public String saleofproductsCreateAction(Model model, @RequestParam employees employee, @RequestParam finishedproducts product,
                                                     @RequestParam String amount, @RequestParam String summa, @RequestParam Date datee){

        Iterable<budget> salebud = SaleBudgetRepos.findAll();
        for (budget but:salebud) {
            but.PlusBudget(Long.parseLong(summa));
        }

        finishedproducts fin = SaleofproductsFinRepos.findById(product.getId()).orElseThrow();
        if (Integer.parseInt(fin.getAmount()) >= Integer.parseInt(amount) &&
                Integer.parseInt(fin.getSumma()) >= Integer.parseInt(summa)){
            fin.MinusAmount(amount);
            fin.MinusSum(summa);
        }else{
            model.addAttribute("ErrorMessage", "Not enough finished products!");
            return "ErrorsPage";
        }


        saleofproducts pr = new saleofproducts(amount, summa, datee, product, employee);
        SaleofproductsRepos.save(pr);
        return "redirect:/saleofproducts";
    }

    @GetMapping("saleofproducts/edit/{id}")
    public String saleofproductsCEdit(Model model, @PathVariable(value = "id") Long id){
        ArrayList<employees> finprodrepos = new ArrayList<>();
        Iterable<employees> finrpoditer = SaleofproductsEmpRepos.findAll();
        for (employees e:finrpoditer) {
            finprodrepos.add(e);
        }
        model.addAttribute("employeesList",finprodrepos);

        ArrayList<finishedproducts> rawmatrepos = new ArrayList<>();
        Iterable<finishedproducts> rawmatiter = SaleofproductsFinRepos.findAll();
        for (finishedproducts e:rawmatiter) {
            rawmatrepos.add(e);
        }
        model.addAttribute("productList",rawmatrepos);

        Optional<saleofproducts> finOp = SaleofproductsRepos.findById(id);
        ArrayList<saleofproducts> res = new ArrayList<>();
        finOp.ifPresent(res::add);
        model.addAttribute("saleofproducts", res);


        return "saleofproductsEdit";
    }
    @PostMapping("/saleofproducts/edit/{id}")
    public String saleofproductsEditAction(Model model, @PathVariable(value = "id") Long id, @RequestParam employees employee,
                                                    @RequestParam finishedproducts product, @RequestParam String amount, @RequestParam String summa, @RequestParam Date datee){

        saleofproducts ing = SaleofproductsRepos.findById(id).orElseThrow();
        Iterable<budget> but = SaleBudgetRepos.findAll();
        for (budget buf:but) {
            if (buf.getSumOfBudget() >= Long.parseLong(summa)){
                buf.MinusBudget(Long.parseLong(ing.getSumma()));
            }else{
                model.addAttribute("ErrorMessage", "Not enough budget!");
                return "ErrorsPage";
            }
        }
        for (budget buf:but) {
            buf.PlusBudget(Long.parseLong(summa));
        }



        finishedproducts fin = SaleofproductsFinRepos.findById(product.getId()).orElseThrow();

        if ((Integer.parseInt(fin.getSumma()) + Integer.parseInt(ing.getSumma())) >= Integer.parseInt(summa) &&
                (Integer.parseInt(fin.getAmount()) + Integer.parseInt(ing.getAmount())) >= Integer.parseInt(amount)){
            fin.PlusAmount(ing.getAmount());
            fin.PlusSum(ing.getSumma());
            fin.MinusAmount(amount);
            fin.MinusSum(summa);
        }else{
            model.addAttribute("ErrorMessage", "Not enough finished  products!");
            return "ErrorsPage";
        }




        ing.setSumma(summa);
        ing.setProduct(product);
        ing.setAmount(amount);
        ing.setEmployee(employee);
        ing.setDatee(datee);
        SaleofproductsRepos.save(ing);

        return "redirect:/saleofproducts";
    }

    @GetMapping("saleofproducts/delete/{id}")
    public String saleofproductsDelete(Model model, @PathVariable(value = "id") Long id){

        Optional<saleofproducts> finOp = SaleofproductsRepos.findById(id);
        ArrayList<saleofproducts> res = new ArrayList<>();
        finOp.ifPresent(res::add);
        model.addAttribute("saleofproducts", res);

        return "saleofproductsDelete";
    }

    @PostMapping("saleofproducts/delete/{id}")
    public String saleofproductsDeleteAction(Model model, @PathVariable(value = "id") Long id){


        saleofproducts sal = SaleofproductsRepos.findById(id).orElseThrow();



        Iterable<budget> but = SaleBudgetRepos.findAll();
        for (budget gut:but) {
            if (gut.getSumOfBudget() >= Long.parseLong(sal.getSumma())){
                gut.MinusBudget(Long.parseLong(sal.getSumma()));
            }else{
                model.addAttribute("ErrorMessage", "Not enough budget!");
                return "ErrorsPage";
            }
        }

        finishedproducts fin = SaleofproductsFinRepos.findById(sal.getProduct().getId()).orElseThrow();
        fin.PlusSum(sal.getSumma());
        fin.PlusAmount(sal.getAmount());


        SaleofproductsRepos.deleteById(id);
        return "redirect:/saleofproducts";
    }



}
